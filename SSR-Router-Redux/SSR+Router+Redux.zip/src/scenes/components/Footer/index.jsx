import React from 'react';

export default React.createClass({
    render() {
        return (
          <div className="footer">Copyright © 2017 - Junxiang</div>
        );
    },
});
